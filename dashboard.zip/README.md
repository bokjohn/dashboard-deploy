# Mission Control Dashboard

Sean & Jon's project management dashboard.

## Access

Visit: https://[username].github.io/mission-control-dashboard

## Features

- Mobile-first responsive design
- Real-time project status
- Todo management (Sean vs Jon)
- Progress tracking
- Quick links to all project files

## Updates

Dashboard updates automatically when Jon makes changes.